<? include "func.php"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>склад товаров -> добавление товаров</title>
</head>
<body>
    <form action="insert_tovars.php" method="post" name="form1">
        Название товара<input type="text" name="name"/> <br>
        Категория товара 
        <select name="category">
            <? echo show_categories();
            ?>
            </select><br>
        Цена товара <input type="text" name="cena"/><br>
        Колличество <input type="number" name="kol"/><br>
        Срок годности <input type="date" name="srok"/><br>
        <input type="submit" name="insert" value="Добавить";></td></tr>
</form> 
</body>
</html>