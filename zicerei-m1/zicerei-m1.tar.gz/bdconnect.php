<?php
$host="localhost";
$user="xpsrbcuf";
$pass="yEbJSX";
$dbName="xpsrbcuf_m1";
$link = mysqli_connect ($host, $user, $pass, $dbName) or die (mysqli_error());
?> 