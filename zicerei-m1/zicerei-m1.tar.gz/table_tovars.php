<h3 align="center">Список товаров</h3>
<table wigth="100%" border="2">
    <tr><td>Номер</td><td>Наиминование</td><td>Цена</td><td>Количество</td><td>Срок годности</td></tr>
    <?php
    include "bdconnect.php";
    $result = mysqli_query($link, "SELECT * FROM tovars");
    while ($row = mysqli_fetch_array($result))
    {
        echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["cena"]."</td><td>".$row["kol"]."</td><td>".$row["srok"]."</td>" ?>
        <?php echo "</tr>";

    }
    ?>
    </table>
    <a href="index.php"> На главную </a>