<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Склад товаров</title>
</head>
<body>
    <h1>Список товаров</h1>
    <?
    include "product.php";
    ?>
    <br>
    <a href="vvod_tovars.php">Добавить товар</a><br>
    <a href="ud_tovars.php">Удалить товар</a><br>
    <a href="table_tovars.php">Посмотреть в виде таблицы</a><br>
</body>
</html>