<?php
 $i=$_GET["i"];
if($i==1) {$st="Данные успешно добавленны";}
if($i==2) {$st="Записи успешно удалены";}
?>
<h4 aling=center>
<?php echo $st ?></h4>
<a href="index.php">На главную</a>
